@extends('layouts.admin')

@section('title', trans_choice('madar.ar_requests', 1) . ' - ' . $arrequest->record_id)

@section('content')
    <!-- Default box -->
    <div class="box box-success">
        {!! Form::model($arrequest, [
            'method' => 'PATCH',
            'files' => true,
            'url' => ['arrequest', $arrequest->id],
            'role' => 'form',
            'id' => 'update_form'
        ]) !!}

        <div class="box-body">
            @if ($arrequest->canProcess())
                <?php $employee_id = $arrequest->employee_id; ?>
                {{ Form::selectGroup('employee', trans_choice('madar.employees', 2), 'id-card-o', $employees, $employee_id, []) }}

                <div class="col-md-6" id="status_field">
                    {{ Form::selectGroup('status', trans('madar.request_status'), 'server', $request_status, $arrequest->status, ['required' => 'required'], 'col-12') }}
                </div>
            @else
                <?php
                $employee = '';
                if (!empty($arrequest->employee)) {
                    $employee = $arrequest->employee->name;
                }
                ?>
                {{ Form::textGroup('approver_name', trans_choice('madar.employees', 2), 'id-card-o', ['disabled' => 'disabled'], $employee) }}

                <div class="col-md-6" id="status_text_field">
                    {{ Form::textGroup('status_text', trans('madar.request_status'), 'server', ['disabled' => 'disabled', 'status_id' => $arrequest->status], $arrequest->statusText(), 'col-12') }}
                    {{ Form::hidden('status', $arrequest->status, ['id' => 'status']) }}
                </div>
            @endif

            <div class="col-md-3" id="sub_status_field">
                {{ Form::selectGroup('sub_status', trans_choice('general.sub_statuses', 2), 'server', auth()->user()->hasRole('admin') ? $request_sub_status : $request_sub_status_b, $arrequest->sub_status, [], 'col-12') }}
            </div>

            {{--@if ($arrequest->canProcess())--}}
                {{--{{ Form::selectGroup('assigned', trans('general.assigned'), 'user', $assigned) }}--}}
            {{--@else--}}
                {{--{{ Form::textGroup('assigned_name', trans('general.assigned'), 'user', ['disabled' => 'disabled'], $arrequest->assignedText()) }}--}}
            {{--@endif--}}

            <div class="form-group col-md-12">
                <p class="control-label"><b>{{ trans_choice('general.notes', 2) }}</b></p>
                <div style="padding-left: 15px;">
                    @foreach($arrequest->notes->reverse() as $note)
                        <div>
                            <div class="no-margin" style="display: flex; justify-content: space-between; align-items: center">
                                <div>
                                    <span><b>{{ $note->user->name }}: </b></span>
                                    <span class="">({{ $note->created_at }})</span>
                                    <span id="update-status-{{ $note->id }}">
                                        @if($note->isUpdated())
                                            (<i class="fa fa-edit"></i> <i>{{ trans('madar.edited') }}</i>)
                                        @endif
                                    </span>
                                </div>
                                @if ($note->user->id == auth()->id())
                                    <div id="btn-group-{{$note->id}}">
                                        <button
                                public                id="edit-btn-{{$note->id}}"
                                                type="button"
                                                class="btn btn-xs btn-info edit-btn"
                                                style="margin-top: 1.5px"
                                                onClick="editNotes({'id': {!! $note->id !!},'notes': `{!! $note->notes !!}`})"
                                        >
                                            <i class="fa fa-edit"></i>
                                        </button>
                                    </div>
                                @endif
                            </div>
                            <div id="note-{{$note->id}}" class="form-group no-padding">
                                <p class="text-muted well well-sm no-shadow">
                                    {!! nl2br(e($note->notes)) !!}
                                </p>
                            </div>
                        </div>
                    @endforeach

                    {{ Form::textareaGroup('notes', trans_choice('general.notes', 2), "", ['rows' => '5']) }}
                </div>
            </div>

            <div class="form-group col-md-6" style="min-height: 59px">
                <div>
                    <label for="attachment[]" class="control-label" style="margin-right: 10px;">{{ trans('general.documents_attachments') }}</label>
                    <button type="button" onclick="addAttachment();" data-toggle="tooltip" title="{{ trans('general.add') }}" class="btn btn-xs btn-primary" data-original-title="{{ trans('general.add') }}"><i class="fa fa-plus"></i></button></td>
                </div>

                <div id="new_attaches">
                </div>

                <div id="cont_attaches">
                </div>
            </div>

            <?php
                $selected = [];
                foreach ($arrequest->monitorUsers as $monitorUser) {
                    array_push($selected, $monitorUser->user->id);
                }
                $disabled = '';
                if ($arrequest->isMonitorUser()) {
                    $disabled = 'disabled';
                }
            ?>
                {{ Form::selectGroup('monitor[]', trans('general.monitor_users'), 'users', $users, $selected, ['class' => 'multiple-select2','placeholder' => null, 'multiple' => 'multiple', $disabled]) }}

                @if ($arrequest->isMonitorUser())
                    @foreach($arrequest->monitorUsers as $monitorUser)
                        {{ Form::hidden('monitor[]', $monitorUser->user->id) }}
                    @endforeach
                @endif

            {{ Form::hidden('name', $arrequest->customer->id) }}
        </div>

        <!-- /.box-body -->

        <div class="box-footer">
            <div class="col-md-12">
                {{--{{ Form::saveButtons(trans('general.submit'), 'arrequest') }}--}}
                <a id="update-button" href="#" class="btn btn-mad-success btn-submit" onclick="showUpdateDialog(); return false;">
                    <i class="fa fa-save"></i>&nbsp; {{ trans('general.save') }}
                </a>
                <a id="update-button1" href="#" class="btn btn-mad-success btn-submit" style="display: none;">
                    <i class="fa fa-save"></i>&nbsp; {{ trans('general.save') }}
                </a>

                <a href="{{ url('arrequest/'.$arrequest->id) }}" class="btn btn-default">
                    <i class="fa fa-times-circle"></i>&nbsp; {{ trans('general.cancel') }}
                </a>
            </div>
        <!-- /.box-footer -->
        </div>

        <input type="submit" style="display:none;" />

        {!! Form::close() !!}
    </div>
@endsection

@push('js')
    <script src="{{ asset('adminlte/plugins/datepicker/bootstrap-datepicker.js') }}"></script>
    <script src="{{ asset('js/bootstrap-fancyfile.js') }}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.1/bootstrap3-typeahead.min.js"></script>
    <script src="{{ asset('adminlte/plugins/colorpicker/bootstrap-colorpicker.js') }}"></script>
    <script src="{{ asset('adminlte/plugins/input-mask/jquery.inputmask.js') }}"></script>
    <script src="{{ asset('adminlte/plugins/input-mask/jquery.inputmask.date.extensions.js') }}"></script>
    <script src="{{ asset('adminlte/plugins/input-mask/jquery.inputmask.extensions.js') }}"></script>
@endpush

@push('css')
    <link rel="stylesheet" href="{{ asset('adminlte/plugins/datepicker/datepicker3.css') }}">
    <link rel="stylesheet" href="{{ asset('css/bootstrap-fancyfile.css') }}">
    <link rel="stylesheet" href="{{ asset('adminlte/plugins/colorpicker/bootstrap-colorpicker.css') }}">
@endpush

@push('scripts')
    <script type="text/javascript">
        var count = 0;
        var is_admin = `{{ auth()->user()->hasRole('admin') }}`;
        var status = `{{ $arrequest->status }}`;
        console.log('status:', status);

        function addAttachment(){
            $("#new_attaches").append('<div style="margin-bottom: 10px;" id="att'+count+'" ><input class="form-control" name="attachment[]" type="file" id="attachment' + count + '"><button type="button" onClick="removeAttachment('+count+');"title="Delete" class="btn btn-xs btn-danger"><i class="fa fa-trash"></i></button>');

            $('#attachment' + count).fancyfile({
                container: '<div class="fancy-file" style="display:inline-block"><div class="fake-file"></div></div>',
                text  : '{{ trans('general.form.select.file') }}',
                style : 'btn-default',
                placeholder : '{{ trans('general.form.no_file_selected') }}'
            });

            count++;
        }

        function removeAttachment(index){
            $("#att" + index).remove();
        }

        function showUpdateDialog() {
            $('#modal-process-ar').remove();

            modal = '<div class="modal fade" id="modal-process-ar" style="display: none;">';
            modal += '  <div class="modal-dialog  modal-lg" style="width:400px;">';
            modal += '      <div class="modal-content">';
            modal += '          <div class="modal-header">';
            modal += '              <h4 class="modal-title">{{ trans('madar.update_ar') }}</h4>';
            modal += '          </div>';
            modal += '          <div class="modal-body">';
            modal += '              <div class="row">';
            modal += '                  <p class="form-group col-md-12">{{ trans('messages.confirm.update') }}</p>';
            modal += '              </div>';
            modal += '          </div>';
            modal += '          <div class="modal-footer">';
            modal += '              <div class="pull-left">';
            modal += '              <button type="submit" class="btn btn-mad-success" data-dismiss="modal" onClick="updateAR(); return false;"><span class="fa fa-save"></span> &nbsp;{{ trans('general.save') }}</button>';
            modal += '              <button type="button" class="btn btn-default" data-dismiss="modal"><span class="fa fa-times-circle"></span> &nbsp;{{ trans('general.cancel') }}</button>';
            modal += '              </div>';
            modal += '          </div>';
            modal += '      </div>';
            modal += '  </div>';
            modal += '</div>';

            $('body').append(modal);

            $('#modal-process-ar').modal('show');
        }

        function updateAR(){
            if ($("#update_form")[0].checkValidity()){
                $("#update_form").submit();
                $("#update-button").hide();
                $("#update-button1").show();
            } else {
                $("#update_form")[0].querySelector('input[type="submit"]').click();
            }
        }

        $(document).ready(function(){
            addAttachment();
            updateSubStatusField();

            $("[data-mask]").inputmask();

            $("#sub_status").select2({
                placeholder: "{{ trans('general.form.select.field', ['field' => trans_choice('madar.request_types', 2)]) }}"
            });

            $("#employee").select2({
                placeholder: "{{ trans('general.form.select.field', ['field' => trans_choice('madar.employees', 2)]) }}"
            });

            $(".multiple-select2").select2({
                placeholder: "{{ trans('general.form.select.users') }}"
            });

            if (is_admin === '1') {
                
                $("#status").select2({
                    placeholder: "{{ trans('general.form.select.field', ['field' => trans_choice('madar.request_types', 2)]) }}"
                });
                
                $("#status").on('change', function (event) {
                    updateSubStatusField();
                });
            }

            {{--$("#assigned").select2({--}}
                {{--placeholder: "{{ trans('general.form.select.field', ['field' => '']) }}"--}}
            {{--});--}}

            @if($arrequest->attachment)
                @foreach($arrequest->attachment as $item)
                    attachment_html  = '<div class="attachment">';
                    attachment_html += '    <a href="{{ url('uploads/' . $item->id . '/download') }}">';
                    attachment_html += '        <span id="download-attachment" class="text-primary">';
                    attachment_html += '            <i class="fa fa-file-{{ $item->aggregate_type }}-o"></i> {{ $item->basename }}';
                    attachment_html += '            <i>({{ $item->uploader }}: {{ $item->created_at }})</i>';
                    attachment_html += '        </span>';
                    attachment_html += '    </a>';
                    @if (!$arrequest->isMonitorUser() || $item->user_id == auth()->id())
                        attachment_html += '    {!! Form::open(['id' => 'attachment-' . $item->id, 'method' => 'DELETE', 'url' => [url('uploads/' . $item->id)], 'style' => 'display:inline']) !!}';
                        attachment_html += '    <a id="remove-attachment-{{ $item->id }}" href="javascript:void();">';
                        attachment_html += '        <span class="text-danger"><i class="fa fa fa-times"></i></span>';
                        attachment_html += '    </a>';
                        attachment_html += '    {!! Form::close() !!}';
                    @endif
                    attachment_html += '</div>';
                    $('#cont_attaches').append(attachment_html);

                    $(document).on('click', '#remove-attachment-' + '{{ $item->id }}', function (e) {
                        confirmDelete("#attachment-{!! $item->id !!}", "{!! trans('general.attachment') !!}", "{!! trans('general.delete_confirm', ['name' => '<strong>' . $item->basename . '</strong>', 'type' => strtolower(trans('general.attachment'))]) !!}", "{!! trans('general.cancel') !!}", "{!! trans('general.delete')  !!}");
                    });
                @endforeach
            @endif

            if ($(".help-block").length <= 0) {
                $('#supplier_name').focus();
            }
        });


        function editNotes(note) {
            $(`#note-${note.id}`).html(
                "<textarea class=\"form-group well-sm no-shadow\" " +
                "id=\"notes-" + note.id + "\"" +
                "rows=\"5\" " +
                "style=\"resize: vertical; width: 100%;\">" +
                note.notes +
                "</textarea>"
            );
            $(`#btn-group-${note.id}`).html("<button\n" +
                "                    id=\"close-btn-"+ note.id +"\"\n" +
                "                    type=\"button\"\n" +
                "                    class=\"btn btn-xs btn-default\"\n" +
                "                    style=\"margin-top: 1.5px;\"\n" +
                "                    onClick=\"closeNotes({" +
                "                   'id':"+note.id+",'notes': `"+ note.notes +"`})\"\n" +
                "                >\n" +
                "                    <i class=\"fa fa-close\"></i>\n" +
                "                </button>\n" +
                "                <button\n" +
                "                    id=\"save-btn-" + note.id + "\"\n" +
                "                    type=\"button\"\n" +
                "                    class=\"btn btn-xs btn-success\"\n" +
                "                    style=\"margin-top: 1.5px;\"\n " +
                "                    onClick=\"saveNotes(" + note.id + ")\"\n" +
                "                >\n" +
                "                    <i class=\"fa fa-save\"></i>\n" +
                "                </button>");
        }
        function closeNotes(note) {
            $(`#note-${note.id}`).html(
                "<p class=\"text-muted well well-sm no-shadow\">" +
                note.notes.replace(/\n/g,'<br/>') +
                "</p>"
            );
            $(`#btn-group-${note.id}`).html("<button\n" +
                "                                id=\"edit-btn-" + note.id +"\"\n" +
                "                                type=\"button\"\n" +
                "                                class=\"btn btn-xs btn-info edit-btn\"\n" +
                "                                style=\"margin-top: 1.5px\"\n" +
                "                                onClick=\"editNotes({" +
                "                               'id':"+note.id+",'notes': `"+ note.notes +"`})\"\n" +
                "                             >\n" +
                "                                <i class=\"fa fa-edit\"></i>\n" +
                "                             </button>");
        }
        function saveNotes(note_id){
            $.ajax({
                url: '{{ url("arrequest/notes/update") }}',
                type: 'POST',
                dataType: 'JSON',
                data: {'note_id': note_id, notes: $(`#notes-${note_id}`).val()},
                headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}' },
                success: function(data) {
                    if (data) {
                        closeNotes({
                            "id": note_id,
                            "notes" : data.notes
                        });
                        $(`#update-status-${note_id}`).html(`(<i class="fa fa-edit"></i> <i>{{ trans('madar.edited') }}</i>)`)
                    }
                }
            });
        }

        function updateSubStatusField() {
            var selected = $("#status").val();
            if (is_admin !== '1') selected = status;

            if (selected === "4") {
                $("#status_field").removeClass('col-md-6').addClass('col-md-3');
                $("#status_text_field").removeClass('col-md-6').addClass('col-md-3');
                $("#sub_status_field").show();
                $("#sub_status").removeAttr('disabled');
            } else {
                $("#status_field").removeClass('col-md-3').addClass('col-md-6');
                $("#status_text_field").removeClass('col-md-3').addClass('col-md-6');
                $("#sub_status_field").hide();
                $("#sub_status").attr('disabled', 'disabled');
            }
        }
    </script>
@endpush


