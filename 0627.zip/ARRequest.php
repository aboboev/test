<?php

namespace App\Models\ARRequests;

use App\Models\Auth\User;
use App\Models\Settings\Customer;
use App\Models\Settings\RequestType;
use App\Traits\Media;
use App\Models\Model;
use Bkwld\Cloner\Cloneable;

use Illuminate\Notifications\Notifiable;

class ARRequest extends Model
{
    use Media, Cloneable, Notifiable;

    protected $table = 'arrequests';

    protected $dates = ['created_at', 'updated_at', 'assigned_at', 'processed_at', 'closed_at', 'shipped_at'];

    protected $appends = ['attachment', 'notes', 'monitor_users'];

    protected $fillable = [
        'record_id',
        'requestor_id',
        'customer_id',
        'employee_id',
        'type',
        'invoice',
        'so_number',
        'po_number',
        'm_number',
        'ncr_number',
        'job_line_number',
        'qty',
        'urgency',
        'status',
        'sub_status',
        'assigned_at',
        'processed_at',
        'closed_at',
        'shipped_at',
    ];

    public $sortable = ['id', 'created_at', 'record_id', 'customer_id', 'employee_id'];

    public function scopeCollect($query, $sort = 'id', $direction = 'desc')
    {
        $request = request();

        $input = $request->input();
        $limit = $request->get('limit', 25);

        return $query->filter($input)->sortable([$sort => $direction])->paginate($limit);
    }

    public function modelFilter()
    {
        $class = '\App\ModelFilters\ARRequests\ARRequests';

        return $this->provideFilter($class);
    }

    public function notes(){
        return $this->hasMany('App\Models\ARRequests\Note', 'arrequest_id', 'id');
    }

    public function monitorUsers(){
        return $this->hasMany('App\Models\ARRequests\MonitorUser', 'arrequest_id', 'id');
    }

    public function getAttachmentAttribute($value)
    {
        if (!empty($value) && !$this->hasMedia('attachment')) {
            return $value;
        } elseif (!$this->hasMedia('attachment')) {
            return false;
        }

        return $this->getMedia('attachment');
    }

    public function getCreatedAtAttribute($value)
    {
        return date("Y-m-d H:i", strtotime($value));
    }

    public function getUpdatedAtAttribute($value)
    {
        return date("Y-m-d H:i", strtotime($value));
    }

    public function getAssignedAtAttribute($value){
        if (!empty($value)) {
            return date("Y-m-d H:i", strtotime($value));
        }

        return "N/A";
    }

    public function getProcessedAtAttribute($value){
        if (!empty($value)) {
            return date("Y-m-d H:i", strtotime($value));
        }

        return "N/A";
    }

    public function getClosedAtAttribute($value){
        if (!empty($value)) {
            return date("Y-m-d H:i", strtotime($value));
        }

        return "N/A";
    }

    public function getShippedAtAttribute($value){
        if (!empty($value)) {
            return date("d/m/Y", strtotime($value));
        }

        return "N/A";
    }

    public function getInvoiceAttribute($value){
        if (!empty($value)) {
            return $value;
        }

        return "N/A";
    }

    public function getSONumberAttribute($value){
        if (!empty($value)) {
            return $value;
        }

        return "N/A";
    }

    public function getMNumberAttribute($value){
        if (!empty($value)) {
            return $value;
        }

        return "N/A";
    }

    public function getPONumberAttribute($value){
        if (!empty($value)) {
            return $value;
        }

        return "N/A";
    }

    public function getNCRNumberAttribute($value){
        if (!empty($value)) {
            return $value;
        }

        return "N/A";
    }

    public function requestType()
    {
        return $this->belongsTo(RequestType::class, 'type');
    }

    public function requestor()
    {
        return $this->belongsTo(User::class, 'requestor_id');
    }

    public function customer()
    {
        return $this->belongsTo(Customer::class, 'customer_id');
        // This is rejected for now. Will use with External Customer (users) in the furture.
//        return $this->belongsTo(User::class, 'customer_id');
    }

    public function employee()
    {
        return $this->belongsTo(User::class, 'employee_id');
    }

//    public function requestType()
//    {
//        return $this->belongsTo(RequestType::class, 'type');
//    }

    public function isCreated()
    {
        return $this->status == config('auth.request_status.created');
    }

    public function isReceived()
    {
        return $this->status == config('auth.request_status.received');
    }

    public function isAssigned()
    {
        return $this->status == config('auth.request_status.assigned');
    }

    public function isInReview()
    {
        return $this->status == config('auth.request_status.in_review');
    }

    public function isClosed()
    {
        return $this->status == config('auth.request_status.closed');
    }

    public function isWaitingForApproval()
    {
        return $this->sub_status == config('auth.request_sub_status.waiting_for_approval');
    }

    public function isPMAction()
    {
        return $this->sub_status == config('auth.request_sub_status.pm_action');
    }

    public function isOnHold()
    {
        return $this->sub_status == config('auth.request_sub_status.on_hold');
    }

    public function isCustomerAction()
    {
        return $this->sub_status == config('auth.request_sub_status.customer_action');
    }

    public function isReturnToFinance()
    {
        return $this->sub_status == config('auth.request_sub_status.return_to_finance');
    }

    public function statusText()
    {
        if ($this->isCreated()){
            return trans("madar.status_created");
        } else if ($this->isReceived()){
            return trans("madar.status_received");
        } else if ($this->isAssigned()){
            return trans("madar.status_assigned");
        } else if ($this->isInReview()){
            return trans("madar.status_in_review");
        } else if ($this->isClosed()){
            return trans("madar.status_closed");
        }
    }

    public function subStatusText()
    {
        if ($this->isWaitingForApproval()){
            return trans("madar.sub_status_waiting_for_approval");
        } else if ($this->isPMAction()){
            return trans("madar.sub_status_pm_action");
        } else if ($this->isOnHold()){
            return trans("madar.sub_status_on_hold");
        } else if ($this->isCustomerAction()){
            return trans("madar.sub_status_customer_action");
        } else if ($this->isReturnToFinance()){
            return trans("madar.sub_status_return_to_finance");
        } else {
            return 'N/A';
        }
    }

    public function statusClass()
    {
        if ($this->isCreated()){
            return "draft bg-aqua";
        } else if ($this->isReceived()){
            return "label-warning";
        } else if ($this->isAssigned()){
            return "bg-green-active";
        } else if ($this->isInReview()){
            return "bg-red";
        } else if ($this->isClosed()){
            return "bg-navy";
        }
    }

    public function isHigh()
    {
        return $this->urgency == config('auth.urgency_status.high');
    }

    public function isMedium()
    {
        return $this->urgency == config('auth.urgency_status.medium');
    }

    public function isLow()
    {
        return $this->urgency == config('auth.urgency_status.low');
    }

    public function urgencyText()
    {
        if ($this->isHigh()){
            return trans('general.high');
        } else if ($this->isMedium()){
            return trans('general.medium');
        } else if ($this->isLow()){
            return trans('general.low');
        }
    }

    public function urgencyClass()
    {
        if ($this->isHigh()){
            return "draft bg-red";
        } else if ($this->isMedium()){
            return "draft bg-aqua";
        } else if ($this->isLow()){
            return "label-warning";
        }
    }

    public function isMoreRequired()
    {
        return $this->assigned == config('auth.assigned.more_required');
    }

    public function isReview()
    {
        return $this->assigned == config('auth.assigned.in_review');
    }

    public function isApproved()
    {
        return $this->assigned == config('auth.assigned.approved');
    }

    public function assignedText()
    {
        if ($this->isMoreRequired()){
            return trans("madar.assigned_more");
        } else if ($this->isReview()){
            return trans("madar.assigned_in_review");
        } else if ($this->isApproved()){
            return trans("madar.assigned_approved");
        }

        return '';
    }

    public function assignedClass()
    {
        if ($this->isMoreRequired()){
            return "draft bg-red";
        } else if ($this->isReview()){
            return "draft bg-aqua";
        } else if ($this->isApproved()){
            return "bg-green-active";
        }
    }

    public function canProcess()
    {
        $user = auth()->user();

        if ($user->hasRole('admin')) {
            return true;
        }
//        else if ($user->hasPermissionTo('ar_process') && $this->employee_id == $user->id){
//            return true;
//        }
        return false;
    }

    public function notesText()
    {
        $text = "";
        foreach ($this->notes->reverse() as $note) {
            $text = $text.$note->user->name.":".$note->created_at."\r\n";
            $text = $text.$note->notes."\r\n\r\n";
        }

        return $text;
    }

    public function isMonitorUser()
    {
        $is_monitor = false;
        if (auth()->user()->hasRole('admin')) return $is_monitor;
        $monitors = $this->monitorUsers;
        $user_id = auth()->id();
        foreach ($monitors as $monitor) {
            if ($monitor->user->id == $user_id && !($user_id == $this->requestor_id || $user_id == $this->employee_id)) {
                $is_monitor = true;
                break;
            }
        }
        return $is_monitor;
    }
}
